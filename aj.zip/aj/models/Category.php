<?php

namespace app\models;
use app\models\SubItem;

use Yii;

/**
 * This is the model class for table "category".
 *
 * @property integer $cid
 * @property string $name
 *
 * @property ItemCategory[] $itemCategories
 * @property Item[] $is
 */
class Category extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'category';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name'], 'required'],
            [['name'], 'string', 'max' => 250],
            [['name'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'cid' => 'Cid',
            'name' => 'Name',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getItemCategories()
    {
        return $this->hasMany(ItemCategory::className(), ['cid' => 'cid']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIs()
    {
        return $this->hasMany(Item::className(), ['iid' => 'iid'])->viaTable('item_category', ['cid' => 'cid']);
    }

    public function getSis()
    {
        return $this->hasMany(SubItem::className(), ['sid' => 'sid'])->viaTable('sub_item_category', ['cid' => 'cid']);
    }
}
