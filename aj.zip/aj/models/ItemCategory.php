<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "item_category".
 *
 * @property integer $iid
 * @property integer $cid
 */
class ItemCategory extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public $flag;
    public static function tableName()
    {
        return 'item_category';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['iid', 'cid'], 'required'],
            ['flag','safe'],
            [['iid', 'cid'], 'integer'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'iid' => 'ITEM',
            'cid' => 'CATEGORY',
        ];
    }

    public function getC()
    {
        return $this->hasOne(Category::className(), ['cid' => 'cid']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getI()
    {
        return $this->hasOne(Item::className(), ['iid' => 'iid']);
    }
}
