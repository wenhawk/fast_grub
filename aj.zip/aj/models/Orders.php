<?php

namespace app\models;

use Yii;
use app\models\Kot;
use yii\base\ErrorException;
/**
 * This is the model class for table "orders".
 *
 * @property integer $tid
 * @property integer $iid
 * @property integer $kid
 * @property integer $quantity
 * @property string $flag
 * @property integer $status
 * @property integer $rank
 *
 * @property Tableaj $t
 * @property Item $i
 * @property Kot $k
 */
class Orders extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'orders';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['tid', 'iid', 'kid', 'quantity', 'flag','rank'], 'required'],
            [['tid', 'iid', 'kid', 'quantity','status','rank'], 'integer'],
            [['status'], 'safe'],
            [['flag'], 'string'],
            [['tid'], 'exist', 'skipOnError' => true, 'targetClass' => Tableaj::className(), 'targetAttribute' => ['tid' => 'tid']],
            [['iid'], 'exist', 'skipOnError' => true, 'targetClass' => Item::className(), 'targetAttribute' => ['iid' => 'iid']],
            [['kid'], 'exist', 'skipOnError' => true, 'targetClass' => Kot::className(), 'targetAttribute' => ['kid' => 'kid']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'tid' => 'TABLE',
            'iid' => 'ITEM',
            'kid' => 'KOT ID',
            'quantity' => 'QUANTITY',
            'flag' => 'Flag',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getT()
    {
        return $this->hasOne(Tableaj::className(), ['tid' => 'tid']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getI()
    {
        return $this->hasOne(Item::className(), ['iid' => 'iid']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getK()
    {
        return $this->hasOne(Kot::className(), ['kid' => 'kid']);
    }

    public static function saveOrders($model,$kot){
        $orders = [];
        for($i = 0 ; $i < sizeof($model->item); $i++){
            $order = new Orders();

           $order->kid =  $kot->kid;                
           $order->iid = $model->item[$i];     
           $order->tid = $model->table[$i];   
           $order->quantity =  $model->quantity[$i];              
           $order->flag = 'true';
           $order->rank = $model->rank[$i];
           $order->save(); 
           array_push($orders,$order); 
                               
       }
       return $orders;
    }

        public static function getOrdersNotInBillKot($tid){
        
                 $billkot = Billkot::find()->all();
                
                $orders = Orders::find()->where(['tid'=>$tid])
                ->andWhere(['not in','kid',$billkot])
                ->andWhere(['flag'=>'true'])
                ->all();

                echo sizeof($orders);
        
                
                $ordersArray = [];
                foreach($orders as $order){
                    $flag = false;
                    foreach($ordersArray as $orderArray){
                        if($orderArray->i->cat == $order->i->cat){
                            $orderArray->quantity =  $orderArray->quantity + $order->quantity;
                            $flag = true;
                            break;
                        }
                    }
                    if(!$flag){
                        array_push($ordersArray,$order);
                    }    
                }
        
                 return $ordersArray;            
        
        }

        public static function getAllOrdersNotInBillKot(){
            
                    $billkot = Billkot::find()->all();
                    
                    $orders = Orders::find()->where(['not in','kid',$billkot])
                    ->andWhere(['flag'=>'true'])
                    ->all();                 
            
                    return $orders;            
            
        }

        public static function getOrdersInBill($bid){
            
                     $billkot = Billkot::find()->where(['bid'=>$bid])->all();
                    
                    $orders = Orders::find()
                    ->where(['in','kid',$billkot])
                    ->andWhere(['flag'=>'true'])
                    ->all();
              
                    
                    $ordersArray = [];
                    foreach($orders as $order){
                        $flag = false;
                        foreach($ordersArray as $orderArray){
                            if($orderArray->i->cat == $order->i->cat){
                                $orderArray->quantity =  $orderArray->quantity + $order->quantity;
                                $flag = true;
                                break;
                            }
                        }
                        if(!$flag){
                            array_push($ordersArray,$order);
                        }    
                    }
            
                     return $ordersArray;            
            
            }

           

    public static function getOrders($startDate,$endDate){
        
                $orders = Orders::find();

                $orders->joinWith('k');

                $orders = $orders->where('timestamp between 
                \''.$startDate.' 00:00:01\' and \''.$endDate.' 23:59:59\'')
                ->andWhere(['flag'=>'true'])
                ->all();

               # echo  'orders size = '.sizeof($orders).'<br>';  
                return $orders;             
        
    }

    public static function getTotalOrderCostPaidBy($startDate,$endDate,$payment_mode){
        
                $bill = Bill::find();

                $bill->joinWith('ks');

                $bills = $bill->where('bill.timestamp between 
                \''.$startDate.' 00:00:01\' and \''.$endDate.' 23:59:59\'')
                ->andWhere(['flag'=>'true'])
                ->andWhere(['payment_mode'=>$payment_mode])
                ->all();


                $cost = 0;
                foreach($bills as $bill){
                    $kots = $bill->ks;
                    foreach($kots as $kot){
                        $orders = $kot->orders;
                        foreach($orders as $order){
                            
                            if($order->flag=='true'){
                                $cost = $cost + ($order->i->cost * $order->quantity);
                            }
                        }
                    }
                }
                
                

               # echo  'orders size = '.sizeof($orders).'<br>';  
                return $cost;             
        
    }

    public static function getOrdersWithUniqueItems($startDate,$endDate){
        
        $orders = Orders::find();
        $orders->joinWith('k');
        $orders = $orders->where('timestamp between 
        \''.$startDate.' 00:00:01\' and \''.$endDate.' 23:59:59\'')
        ->andWhere(['flag'=>'true'])
        ->groupBy('iid')
        ->all();
        
        # echo  'item size = '.sizeof($orders).'<br>';    
         
         return $orders;  
        
    }


    public static function getItemOrdersQuantity($startDate,$endDate,$item){
        
        $orders = Orders::find();
        $orders->joinWith('k');
        $quantity = $orders->where('timestamp between 
        \''.$startDate.' 00:00:01\' and \''.$endDate.' 23:59:59\'')
        ->andWhere(['iid'=>$item->iid])
        ->andWhere(['flag'=>'true'])
        ->sum('quantity');

        # echo  $item->name.' count='.$quantity.'<br>';   
         
        return $quantity;  
        
    }

    public static function getItemOrdersCost($startDate,$endDate,$item){
        
        $orders = Orders::find();
        $orders->joinWith('k');
        $orders->joinWith('i');
        $cost = $orders->where('timestamp between 
        \''.$startDate.' 00:00:01\' and \''.$endDate.' 23:59:59\'')
        ->andWhere(['item.iid'=>$item->iid])
        ->andWhere(['flag'=>'true'])
        ->sum('cost');

         #echo  $item->name.' count='.$cost.'<br>';   
         
        return $cost;  
        
    }

   
}
