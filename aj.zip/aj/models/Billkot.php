<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "billkot".
 *
 * @property integer $bid
 * @property integer $kid
 * @property string $flag
 *
 * @property Bill $b
 * @property Kot $k
 */
class Billkot extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'billkot';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['bid', 'kid'], 'required'],
            [['bid', 'kid'], 'integer'],
            [['flag'], 'string'],
            [['bid'], 'exist', 'skipOnError' => true, 'targetClass' => Bill::className(), 'targetAttribute' => ['bid' => 'bid']],
            [['kid'], 'exist', 'skipOnError' => true, 'targetClass' => Kot::className(), 'targetAttribute' => ['kid' => 'kid']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'bid' => 'Bid',
            'kid' => 'Kid',
            'flag' => 'Flag',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getB()
    {
        return $this->hasOne(Bill::className(), ['bid' => 'bid']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getK()
    {
        return $this->hasOne(Kot::className(), ['kid' => 'kid']);
    }
}
