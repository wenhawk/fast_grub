<?php

namespace app\models;
use yii\base\Model;

use Yii;

class KotItem extends Model
{
   public $item;
   public $quantity;
   public $table;
   public $count;
   public $subitem;
   public $rank;

   public function rules()
   {
       return [
           [['item','quantity','table','subitem','count','index','rank'], 'required'],
       ];
   }
}
