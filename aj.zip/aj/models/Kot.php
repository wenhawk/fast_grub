<?php

namespace app\models;
use Mike42\Escpos\Printer;
use Mike42\Escpos\PrintConnectors\FilePrintConnector;
use app\models\Orders;
use app\models\Billkot;
use Mike42\Escpos\ImagickEscposImage;
use Yii;

/**
 * This is the model class for table "kot".
 *
 * @property integer $kid
 * @property string $timestamp
 *
 * @property Billkot[] $billkots
 * @property Bill[] $bs
 * @property Orders[] $orders
 */
class Kot extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'kot';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['timestamp'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'kid' => 'KOT ID',
            'timestamp' => 'Timestamp',
        ];
    }

    public static function getKotNotInBillKot($tid){

        $billkot = Billkot::find()->all();
        
        $orders = Orders::find()->where(['tid'=>$tid])
        ->andWhere(['not in','kid',$billkot])
        ->groupBy('kid')
        ->all();

        $kot = [];
        for($i = 0 ; $i < sizeof($orders) ; $i++){
            $kot[$i] = $orders[$i]->k;
        }

        return $kot;

    }

    
    public static function printKot($kid){
        $orders = Orders::find()->where(['kid'=>$kid])->orderBy('rank')->all();
            if(!sizeof($orders)==0){
            $connector = new FilePrintConnector("/dev/usb/lp0");
            $printer = new Printer($connector);          
            $printer -> setEmphasis(true);
            $printer-> setTextSize(2,2);
            $printer -> feed(4);
            $printer -> text('KOT ID: '.$orders[0]->kid);
            $printer -> feed(1);
            $printer -> text($orders[0]->t->name);
            $printer -> feed(1);
            $printer-> setTextSize(1,2); 
            foreach($orders as $order){
                 $printer -> setEmphasis(false); 
                 $printer -> text($order->i->name.' x '.$order->quantity); 
                 $printer -> feed(1); 
            }    
            $printer -> feed(5);  
            $printer->close(); 
         }         
    }

    public function generateKot(){
        date_default_timezone_set("Asia/Kolkata"); 
        $this->timestamp = date("Y-m-d H:i:s");
        $this->save();
    }


     /**
     * @return \yii\db\ActiveQuery
     */
    public function getBillkots()
    {
        return $this->hasMany(Billkot::className(), ['kid' => 'kid']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBs()
    {
        return $this->hasMany(Bill::className(), ['bid' => 'bid'])->viaTable('billkot', ['kid' => 'kid']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOrders()
    {
        return $this->hasMany(Orders::className(), ['kid' => 'kid']);
    }


    public static function getKots($startDate,$endDate){
        
        $kot = Kot::find()->where('timestamp between 
        \''.$startDate.' 00:00:01\' and \''.$endDate.' 23:59:59\'')
        ->all();
        
        return $kot;
        
    }
}
