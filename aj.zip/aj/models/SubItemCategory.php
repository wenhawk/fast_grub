<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "sub_item_category".
 *
 * @property integer $sid
 * @property integer $cid
 *
 * @property Category $c
 * @property SubItem $s
 */
class SubItemCategory extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public $flag;
    public static function tableName()
    {
        return 'sub_item_category';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['sid', 'cid'], 'required'],
            [['sid', 'cid'], 'integer'],
            ['flag','safe'],
            [['cid'], 'exist', 'skipOnError' => true, 'targetClass' => Category::className(), 'targetAttribute' => ['cid' => 'cid']],
            [['sid'], 'exist', 'skipOnError' => true, 'targetClass' => SubItem::className(), 'targetAttribute' => ['sid' => 'sid']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'sid' => 'SUB ITEM',
            'cid' => 'CATOGORY',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getC()
    {
        return $this->hasOne(Category::className(), ['cid' => 'cid']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getS()
    {
        return $this->hasOne(SubItem::className(), ['sid' => 'sid']);
    }
}
