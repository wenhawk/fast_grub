<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "tableaj".
 *
 * @property integer $tid
 * @property string $name
* @property string $flag
 * @property Orders[] $orders
 */
class Tableaj extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'tableaj';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name','flag'], 'required'],
            [['name'], 'string', 'max' => 250],
            [['name'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'tid' => 'Tid',
            'name' => 'TABLE NAME',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOrders()
    {
        return $this->hasMany(Orders::className(), ['tid' => 'tid']);
    }

    public static function getAllTablesBillNotGenerated(){
        $billkot = Billkot::find()->all();

        $orders = Orders::find()->where(['not in','kid',$billkot])
        ->groupBy('tid')
        ->all();

        return $orders;

    }
}
