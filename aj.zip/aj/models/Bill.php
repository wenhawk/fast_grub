<?php

namespace app\models;
use app\models\ItemCategory;

use Mike42\Escpos\Printer;
use Mike42\Escpos\PrintConnectors\FilePrintConnector;

use Yii;

/**
 * This is the model class for table "bill".
 *
 * @property integer $bid
 * @property string $timestamp
 * @property string $payment_mode
 * @property integer $discount
 *
 * @property Billkot[] $billkots
 * @property Kot[] $ks
 */
class Bill extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'bill';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['timestamp'], 'safe'],
            [['payment_mode'], 'required'],
            [['payment_mode'], 'string'],
            [['discount'], 'integer'],
            [['timestamp'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'bid' => 'BILL ID',
            'timestamp' => 'TIMESTAMP',
            'payment_mode' => 'PAYMENT MODE',
            'discount' => 'DISCOUNT',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBillkots()
    {
        return $this->hasMany(Billkot::className(), ['bid' => 'bid']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getKs()
    {
        return $this->hasMany(Kot::className(), ['kid' => 'kid'])->viaTable('billkot', ['bid' => 'bid']);
    }

  
    public static function getOrders($bill){
        $billKot = new Billkot();
        
        $billKot=$billKot->find()
        ->where(['bid'=>$bill->bid])
        ->all();
        
        $orders = [];
        foreach($billKot as $bk){
        
            $kot=Kot::findOne($bk->kid);            
            $order = $kot->orders;
            
            foreach($order as $o){
                array_push($orders,$o);
            }
                    
        }
        return $orders;
    }

    public static function getDistinctOrders($orders){
        $item = [];       
        
          foreach($orders as $o1){  
              $flag= true;
              foreach($item as $i){  
                  if($i->iid == $o1->iid){
                      $i->quantity = $o1->quantity + $i->quantity;
                      $flag= false;                    
                  }
              }
              if($flag == true && $o1->flag == 'true')  {
                  array_push($item,$o1);
              }
          }       
          return $item;
    }

    public static function getArrayOfCategoryQuantityOrder($item){
        $cat = [];
        $quan = [];
        $ord = [];

        foreach($item as $i){

        $count=ItemCategory::find()
        ->where(['iid'=>$i->i->iid])
        ->count();    

        if($count == 1){
            $flag = true;
            $category=ItemCategory::find()
            ->where(['iid'=>$i->i->iid])
            ->one();

            $category = $category->c;

            for($j = 0; $j < sizeof($cat); $j++){
                if($cat[$j]->cid == $category->cid ){
                    $quan[$j] =  $quan[$j] + $i->quantity;
                    $flag = false;
                }
            }

            if($flag){
                array_push($cat,$category);
                array_push($quan,$i->quantity);
            }     
        
        }else{
            array_push($ord,$i); 
        }                  
      }

      $array[0] = $cat;
      $array[1] = $quan;
      $array[2] = $ord;

      return $array;

    }

    public static function getQuantityItemArray($bill){

      $orders = Orders::getOrders($bill);

      $item = Bill:: getDistinctOrders($orders);

      $array = Bill:: getArrayOfCategoryQuantityOrder($item);     

       
      $cat = $array[0];
      $quan = $array[1];
      $ord = $array[2];       

      $finalItemArray = [];
      $finalQuantityArray = [];
      $finalCostArray = [];

      for($i = 0; $i < sizeof($cat); $i++){
       array_push($finalItemArray,$cat[$i]->name);
       array_push($finalQuantityArray,$quan[$i]);

       $category = Category::find()->where(['name'=>$cat[$i]])->one();
       $items = $category->is;
       $cost = $items[0]->cost; 

       array_push($finalCostArray,$cost);
       } 

      foreach($ord as $o){
        array_push($finalItemArray, $o->i->name);
        array_push($finalQuantityArray,$o->quantity);
        array_push($finalCostArray,$o->i->cost);
      } 

        $array[0] = $finalItemArray;
        $array[1] = $finalQuantityArray;
        $array[2] = $finalCostArray;

        return $array;
    }

    public static function printBill($bid){        
        
       $orders = Orders::getOrdersInBill($bid);
       if(sizeof($orders)>0){
        $bill = Bill::findOne($bid);
        
        
                $connector = new FilePrintConnector("/dev/usb/lp0");
                $printer = new Printer($connector);        
                
                $printer -> setEmphasis(true); 
                $printer-> setTextSize(2,2);
                $printer-> setJustification(Printer::JUSTIFY_CENTER);
                $printer -> text('AJ\'s');
                $printer -> feed(1);
                $printer -> setEmphasis(false); 
                $printer-> setTextSize(1,1);
                $printer -> setFont(Printer::FONT_A);
                $printer -> text('K.K White House, House No.1336');
                $printer -> feed(1);
                $printer -> text('Don Bosco RD,Murida, Fatorda');
                $printer -> feed(1);
                $printer -> text('Goa - 403602,');
                $printer -> feed(1);
                $printer -> text('PH: +91 9923204220');
                $printer -> feed(1);    
                $printer -> text($orders[0]->t->name.'   '.date("Y-d-m H:i:s"));
                $printer -> feed(1);
                $printer -> text("BILL ID: ".$bill->bid);
                $printer -> feed(1);
                $printer -> setEmphasis(true);
                $printer -> setFont(Printer::FONT_A);
                $printer -> feed(1);
                $printer-> setJustification(Printer::JUSTIFY_LEFT);
                $printer -> text('--------------------------------');
                $printer -> feed(1);
                $printer-> setJustification(Printer::JUSTIFY_LEFT);
                $printer -> text('Item             Qt  Rate    Amt');  
                $printer -> text('--------------------------------'); 
                 $subTotal = 0;
                 for($i = 0; $i < sizeof($orders); $i++){
                         $printer -> setEmphasis(false);                
                        if(strlen($orders[$i]->i->cat)<15){
                            $printer -> text($orders[$i]->i->cat.'  ');
                            for($j = 0; $j <   15-strlen($orders[$i]->i->cat)  ; $j++){
                                $printer -> text(' ');
                            }
                        }else{
                            $start = 0;
                            $end = 15;
                            $count = strlen($orders[$i]->i->cat)/15;
                            $string = $orders[$i]->i->cat;
                            for($k = 0; $k < $count  ; $k++){
                                $str = substr($orders[$i]->i->cat,$start,15);
                                for($j = 0; $j <  15 - strlen($str)  ; $j++){
                                    $printer -> text(' ');
                                }
                                $printer -> feed(1);
                                $printer -> text($str);
                                if(strlen($str)<17){
                                    for($j = 0; $j <   17-strlen($str)  ; $j++){
                                        $printer -> text(' ');
                                    }
                                }
                                $start = $start + 15;
                            } 
                        }                   
                           
        
                        $quantity =  ($orders[$i]->quantity);
                        if(strlen($orders[$i]->quantity)==1){
                            $quantity = ' '.$quantity;
                        }
                        $printer -> text($quantity.'  ');
        
                        $cost =  ($orders[$i]->i->cost);
                        if(strlen($quantity)>1){
                            for($j = 0; $j <   4-strlen($cost)  ; $j++){
                                $printer -> text(' ');
                            }
                        }
                        $printer -> text($orders[$i]->i->cost.'  ');
        
                        $amount =  ($orders[$i]->i->cost*$orders[$i]->quantity);
                        if(strlen($quantity)>1){
                            for($j = 0; $j <   5-strlen($amount)  ; $j++){
                                $printer -> text(' ');
                            }
                        }
                        $printer -> text($orders[$i]->i->cost*$orders[$i]->quantity);
                        $printer -> feed(1);
                        $printer -> text('................................');
                        $printer -> feed(1);
                        $subTotal = $subTotal + $orders[$i]->i->cost*$orders[$i]->quantity; 
                 }         
                 $printer -> setFont(Printer::FONT_A);
                 if($bill->discount==0){
                    $printer -> setEmphasis(true); 
                    $printer -> text('TOTAL                   Rs '.$subTotal);     
                    $printer -> feed(1);
                 }else{
                    $printer -> setEmphasis(true); 
                    $printer -> text('SUB TOTAL               Rs '.$subTotal);     
                    $printer -> feed(1);
                    $discount = ($subTotal*$bill->discount)/100;   
                    $printer -> text('DISCOUNT                Rs '.$discount);  
                    $printer -> feed(1);
                    $printer -> text('TOTAL                   Rs '.($subTotal-$discount));  
                    $printer -> feed(1);
                    /* $printer -> text('TOTAL                   Rs 100'.$subTotal-$discount);     
                    $printer -> feed(1); */
                 }
                
                $printer -> feed(1);
                $printer -> setEmphasis(false);
                $printer-> setJustification(Printer::JUSTIFY_LEFT);
                $printer -> text('COMPOSITION TAXABLE PERSON');
                $printer -> feed(1);
                $printer -> text('GSTIN: 30AFGPG9096R1ZT');
                $printer -> feed(1);
                $printer -> setEmphasis(true);
                $printer-> setJustification(Printer::JUSTIFY_CENTER);
                $printer -> text('FREE HOME DELIVERY');
                $printer -> feed(4);
                $printer->close(); 
       }
       
    }
}
