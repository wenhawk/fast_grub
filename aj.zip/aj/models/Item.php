<?php

namespace app\models;
use app\models\Category;

use Yii;

/**
 * This is the model class for table "item".
 *
 * @property integer $iid
 * @property string $name
 * @property string $description
 * @property integer $cost
 * @property string $flag
 *  @property string $cat
 * 
 * @property Orders[] $orders
 */
class Item extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'item';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'cost','flag'], 'required'],
            [['description'], 'string'],
            [['cost'], 'integer'],
            [['cat'],'safe'],
            [['name'], 'string', 'max' => 250],
            [['name'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'iid' => 'Iid',
            'name' => 'ITEM NAME',
            'description' => 'Description',
            'cost' => 'Cost',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOrders()
    {
        return $this->hasMany(Orders::className(), ['iid' => 'iid']);
    }

    public function getCs()
    {
        return $this->hasMany(Category::className(), ['cid' => 'cid'])->viaTable('item_category', ['iid' => 'iid']);
    }

  
}
