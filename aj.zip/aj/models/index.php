<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>

<style>

.col-md-4{
   border: 2px solid black;
   padding: 10px;   
}

.row{
   padding: 5px;   
}



</style>
<center>
<div class = 'container'>
    <div class='row'>
        <div class='col-md-3'>
        <h2> <a href='index.php?r=tableaj/show-deleted-table' class='btn btn-success'> SHOW DELETED TABLES </a> </h2>
        </div>
        <div class='col-md-3'>
        <h2> <a href='index.php?r=tableaj/create' class='btn btn-success'> CREATE NEW TABLE </a> </h2>
        </div>
    
    </div>

<div class = 'row'>
    <?php foreach($table as $t) {?>
    <div class = 'col-md-4'>         
         
        <h3> <a href='index.php?r=tableaj/delete-table&amp;tid=<?=$t->tid ?>' class='btn btn-danger'> X </a> </h2>

        <h1><?= $t->name ?></h1>

        <a href= 'index.php?r=kot/generate&amp;id=<?=$t->tid ?>'> 
            <h4>Generate Kot</h4>
        </a>    
        <a href= 'index.php?r=bill/view&amp;id=<?=$t->tid ?>'> 
            <h4>Generate Bill</h4>
        </a>
        <a href= 'index.php?r=kot/view-table-kot&amp;tid=<?=$t->tid ?>'> 
            <h4>Table Status</h4>
        </a>
    </div>
    <?php }?>
</div>
</div>
</center>