<?php

namespace app\models;
use yii\base\Model;

use Yii;

class BillKot extends Model
{
   public $kot;

   public function rules()
   {
       return [
           [['kot'], 'required'],
       ];
   }
}
