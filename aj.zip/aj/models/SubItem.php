<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "sub_item".
 *
 * @property integer $sid
 * @property string $name
 * @property string $flag
 */
class SubItem extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'sub_item';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name'], 'required'],
            ['flag','safe'],
            [['name'], 'string', 'max' => 250],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'sid' => 'Sid',
            'name' => 'Name',
        ];
    }
}
