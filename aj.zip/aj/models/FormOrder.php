<?php

namespace app\models;
use yii\base\Model;

use Yii;

class FormOrder extends Model
{
   public $kid;
   public $iid;
   public $quantity;
   public $flag;
   public $status;
   public $uniqueKid;
   public $paymentMode;
   public $discount;
   public $rank;

   public function rules()
   {
       return [
           [['kid','iid','quantity','flag','uniqueKid','paymentMode','discount','status','rank'], 'required'],
       ];
   }
}