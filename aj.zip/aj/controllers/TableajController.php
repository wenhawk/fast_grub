<?php

namespace app\controllers;

use Yii;
use app\models\Tableaj;
use app\models\TableajSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * TableajController implements the CRUD actions for Tableaj model.
 */
class TableajController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Tableaj models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new TableajSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Tableaj model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Tableaj model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Tableaj();

        if ($model->load(Yii::$app->request->post())) {
            $model->flag = 'true';
            $model->save();
            return $this->redirect('index.php');
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing Tableaj model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->tid]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Tableaj model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $model = Tableaj::findOne($id);
        $model->flag = 'false';
        $model->save();

        return $this->redirect(['index']);
    }

    public function actionDeleteTable($tid)
    {
        $model = Tableaj::findOne($tid);
        $model->flag = 'false';
        $model->save();

        return $this->redirect('index.php');
    }

    public function actionRestoreTable($tid)
    {
        $model = Tableaj::findOne($tid);
        $model->flag = 'true';
        $model->save();

        $model = Tableaj::find()->where(['flag'=>'false'])->all();
        
        return $this->render('showDeletedTables', [
            'model' => $model,
        ]);
    }

    public function actionShowDeletedTable()
    {
        $model = Tableaj::find()->where(['flag'=>'false'])->all();

        return $this->render('showDeletedTables', [
            'model' => $model,
        ]);
    }

    /**
     * Finds the Tableaj model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Tableaj the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Tableaj::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
