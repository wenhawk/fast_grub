<?php

namespace app\controllers;

use Yii;
use app\models\Orders;
use app\models\Kot;
use app\models\OrdersSearch;
use app\models\Report;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * OrdersController implements the CRUD actions for Orders model.
 */
class OrdersController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Orders models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new OrdersSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Orders model.
     * @param integer $tid
     * @param integer $iid
     * @param integer $kid
     * @return mixed
     */
    public function actionView($tid, $iid, $kid)
    {
        return $this->render('view', [
            'model' => $this->findModel($tid, $iid, $kid),
        ]);
    }

    /**
     * Creates a new Orders model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Orders();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'tid' => $model->tid, 'iid' => $model->iid, 'kid' => $model->kid]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    public function actionReport()
    {
        $model = new Report();

        if ($model->load(Yii::$app->request->post())) {
            
                $startDate = $model->startDate;
                $endDate = $model->endDate;
    
                if($endDate == ''){
                  $endDate =  $startDate;
                }

                $kot = Kot::getKots($startDate , $endDate);
                $allOrders = Orders::getOrders($startDate , $endDate);
                $orderItem = Orders::getOrdersWithUniqueItems($startDate,$endDate);
                $quantity = [];
                $cost = 0;

                foreach($orderItem as $oi){
                    $quan = Orders:: getItemOrdersQuantity($startDate,$endDate,$oi->i);
                    array_push($quantity,$quan);
                    $cost = $cost + ($oi->i->cost * $quan)  ;
                }
                echo $cost ;

               $totalCashCost=  Orders::getTotalOrderCostPaidBy($startDate,$endDate,'cash');
               $totalCardCost=  Orders::getTotalOrderCostPaidBy($startDate,$endDate,'card');

                   return $this->render('report', [
                     'kot' => $kot,
                     'allOrders' => $allOrders,
                     'orderItem' => $orderItem,
                     'quantity' => $quantity,
                     'cost' => $cost,
                     'cash' => $totalCashCost,
                     'card' => $totalCardCost,
                ]);    
                
          
        }else{
            return $this->render('reportDate', [
                ]);
        }
    }

    /**
     * Updates an existing Orders model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $tid
     * @param integer $iid
     * @param integer $kid
     * @return mixed
     */
    public function actionUpdate($kid, $tid, $iid,$rank,$status)
    {
        $model = Orders::find()->where(['kid'=>$kid,'tid'=>$tid,'iid'=>$iid,'rank'=>$rank,])->one();
        $model->status = $status;
        $model->save();

        $model = Orders::getAllOrdersNotInBillKot();
        
                return $this->render('viewAllOrders', [
                    'model' => $model,
            ]);

    }

    /**
     * Deletes an existing Orders model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $tid
     * @param integer $iid
     * @param integer $kid
     * @return mixed
     */
    public function actionDelete($tid, $iid, $kid)
    {
        $this->findModel($tid, $iid, $kid)->delete();

        return $this->redirect(['index']);
    }

    public function actionViewAllOrders()
    {
        $model = Orders::getAllOrdersNotInBillKot();

        return $this->render('viewAllOrders', [
            'model' => $model,
        ]);
    }
    

    /**
     * Finds the Orders model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $tid
     * @param integer $iid
     * @param integer $kid
     * @return Orders the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($tid, $iid, $kid)
    {
        if (($model = Orders::findOne(['tid' => $tid, 'iid' => $iid, 'kid' => $kid])) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
