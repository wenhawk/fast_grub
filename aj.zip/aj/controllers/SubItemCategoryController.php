<?php

namespace app\controllers;

use Yii;
use app\models\SubItemCategory;
use app\models\SubItemCategorySearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * SubItemCategoryController implements the CRUD actions for SubItemCategory model.
 */
class SubItemCategoryController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all SubItemCategory models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new SubItemCategorySearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single SubItemCategory model.
     * @param integer $sid
     * @param integer $cid
     * @return mixed
     */
    public function actionView($sid, $cid)
    {
        return $this->render('view', [
            'model' => $this->findModel($sid, $cid),
        ]);
    }

    /**
     * Creates a new SubItemCategory model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new SubItemCategory();
        
                if ($model->load(Yii::$app->request->post())) {
                    echo 'size sid='.sizeof($model->sid).'<br>';
                    echo 'size cid='.sizeof($model->cid).'<br>';
                    echo 'size flag='.sizeof($model->flag).'<br>';
        
                    $flag_string = '';
                    foreach($model->flag as  $flag){
                        $flag_string = $flag_string.''.$flag;
                    }
                    $flag_string=str_replace("01","1",$flag_string);
        
                    $flag = [];
                    for($i = 0 ; $i < strlen($flag_string); $i++){
                        array_push($flag,$flag_string[$i]);
                    } 
                    echo 'flag='.sizeof($flag).'<br>';
        
                    for($i = 0; $i < sizeof($model->sid);  $i++){
                        
                        if($flag[$i]==1){
                            echo 'sid='.$model->sid[$i].' ';
                            echo 'cid='.$model->cid.'<br>';
                            echo 'flag='.$flag[$i].'<br>';
                            $itemCategory = new SubItemCategory();
                            $itemCategory->sid = $model->sid[$i];
                            $itemCategory->cid = $model->cid;
                            $save = $itemCategory->save();
                            echo 'save='.$save.'<br>';
                            ;
                        }
                    }
                   /*  return $this->redirect('index'); */
                } else {
                    return $this->render('create', [
                        'model' => $model,
                    ]);
                }
    }

    /**
     * Updates an existing SubItemCategory model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $sid
     * @param integer $cid
     * @return mixed
     */
    public function actionUpdate($sid, $cid)
    {
        $model = $this->findModel($sid, $cid);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'sid' => $model->sid, 'cid' => $model->cid]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing SubItemCategory model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $sid
     * @param integer $cid
     * @return mixed
     */
    public function actionDelete($sid, $cid)
    {
        $this->findModel($sid, $cid)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the SubItemCategory model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $sid
     * @param integer $cid
     * @return SubItemCategory the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($sid, $cid)
    {
        if (($model = SubItemCategory::findOne(['sid' => $sid, 'cid' => $cid])) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
