<?php

namespace app\controllers;

use Yii;
use app\models\Kot;
use app\models\KotSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\Item;
use app\models\SubItem;
use app\models\Billkot;
use app\models\ItemSearch;
use app\models\KotItem;
use app\models\Orders;
use app\models\Bill;
use app\models\Tableaj;
use app\models\FormOrder;
use app\models\Category;
use yii\helpers\Json;
/**
 * KotController implements the CRUD actions for Kot model.
 */
class KotController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    public function actionUpdateAndPrint()
    {
        $orders = new FormOrder();
        $orders->load(Yii::$app->request->post());

        if(sizeof($orders->flag )> 0){
       $flag_string = '';
       foreach($orders->flag as  $flag){
            $flag_string = $flag_string.''.$flag;
        }
        $flag_string=str_replace("01","1",$flag_string);
        $flag = [];
            for($i = 0 ; $i < strlen($flag_string); $i++){
                array_push($flag,$flag_string[$i]);
        }
        
        $status_string = '';
        foreach($orders->status as $status){     
             $status_string = $status_string.''.$status;
         }
        $status_string=str_replace("01","1",$status_string);        
        $status = [];
        for($i = 0 ; $i < strlen($status_string); $i++){
            array_push($status,$status_string[$i]);
        } 

        echo '<br>'.sizeof($orders->status);   
        echo '<br>'.sizeof($orders->flag); 

          $orderArray = [];
        for($i = 0 ; $i < sizeof($orders->iid); $i++){

            $order = Orders::find()
            ->where(['iid'=>$orders->iid[$i]])
            ->andWhere(['kid'=>$orders->uniqueKid])
            ->andWhere(['rank'=>$orders->rank[$i]])
            ->one();

            echo '<br>'.sizeof($order);
            
            $order->quantity = $orders->quantity[$i];
            $order->status = $status[$i];

            if($flag[$i]==0){
                echo '<br>true';
                $order->flag= 'true';
                array_push($orderArray,$order);
            }else{
                echo '<br>false';
                $order->flag = 'false';
            } 
            $order->save();
        }  

        /* Kot::printKot($orderArray); */   
        }
        

           return $this->redirect('index.php');    
    }

    public function actionPrint($kid){
        try {
            Kot::printKot($kid);  
        } catch (ErrorException $e) {
            Yii::warning("Division by zero.");
        }
       
        return $this->redirect('index.php');   
    }

    public function actionGenerate($id)
    {
        $model = new KotItem();
        if ($model->load(Yii::$app->request->post())){

              $initialCount = 0;
            for($i = 0; $i < sizeof($model->count); $i++){
                $item = Item::findOne($model->item[$i]);
                if($model->count[$i]!=0){
                    $subItemString = ' ';
                    for($j = 0;$j < $model->count[$i] ; $j++){
                        $subItem = SubItem::findOne($model->subitem[$initialCount]);
                        $subItemString =  $subItemString .' '.$subItem->name;
                        $initialCount++;     
                    } 
                    $count = Item::find()->where(['name'=>$item->name.' '.$subItemString])->one();
                    if(sizeof($count) == 1){
                        $model->item[$i]  = $count->iid;
                    }else{
                        $newItem = new Item();
                        $newItem->name = $item->name.' '.$subItemString;
                        $newItem->flag = 'false';
                        $newItem->cost = $item->cost;
                        $newItem->description = '';
                        $newItem->cat = $item->name;
                        $newItem->save();
                        $model->item[$i] = $newItem->iid;
                    }
                    
                }
            }

            $kot = new Kot();
            $kot->generateKot();

           Orders::saveOrders($model,$kot);           
           $orders = Orders::find()->where(['kid'=>$kot->kid])->orderBy('rank')->all();           
 
            return $this->render('viewKot', [
                'orders' => $orders,
            ]);                  
        }
         else
        {
            return $this->render('generate', [
                'tableID' => $id
            ]);
        } 
 
    }

    public function actionAjax($id){
        $item = Item::find()->where(['iid' => $id])->one();
        $categorys = $item->cs; 
        $subItemArray = [];
        foreach($categorys as $cat){
            $subItem = $cat->sis;
            array_push($subItemArray,$subItem);
        }
        $subItemArray = JSON::encode($subItemArray); 
        return $subItemArray; 
    }

    public function actionViewKot($tid){
        
        $billkot = Billkot::find()->all();

        $orders = Orders::find()->where(['tid'=>$tid])
        ->andWhere(['not in','kid',$billkot])
        ->all();

        return $this->render('viewKot', [
            'orders' => $orders,
        ]);
        
    } 
    
    public function actionViewTableKot($tid){
        
        $billkot = Billkot::find()->all();

        $orders = Orders::find()->where(['tid'=>$tid])
        ->andWhere(['not in','kid',$billkot])
        ->groupBy('kid')
        ->all();

        return $this->render('viewTableKot', [
            'kots' => $orders,
        ]);
        
    } 
    
    /**
     * Lists all Kot models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new KotSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Kot model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Kot model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Kot();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->kid]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing Kot model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {   
            
            $kot = Kot::findOne($id);
            $orders = Orders::find()->where(['kid'=>$kot->kid])->orderBy('rank')->all();   

            return $this->render('viewKot', [
                'orders' => $orders,
            ]);      
        
        
    }

    /**
     * Deletes an existing Kot model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Kot model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Kot the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Kot::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
