<?php

namespace app\controllers;

use Yii;
use app\models\Bill;
use app\models\Billkot;
use app\models\BillSearch;
use app\models\Orders;
use app\models\Kot;
use app\models\KotArray;
use app\models\FormOrder;
use app\models\Tableaj;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * BillController implements the CRUD actions for Bill model.
 */
class BillController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Bill models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new BillSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    public function actionGenerate(){
        
        $model = new Tableaj();

        if ($model->load(Yii::$app->request->post())){
            $kots = Kot::getKotNotInBillKot($model->name);

            return $this->render('view', [
                'tableaj' => $model,
                'kot'=>$kots,
            ]);  

        }
        else{
             $orders = Tableaj::getAllTablesBillNotGenerated();
             return $this->render('selectTable' ,['orders' => $orders]);  
        }        
        
    }

    public function actionView($id)
    {
        $orders = Orders::getOrdersNotInBillKot($id);
        $model = Tableaj::findOne($id);

        return $this->render('view', [
        'tableaj' => $model,
        'kot'=>$orders,
        'isUpdate' => false
        ]);  
    }

    public function actionInsert(){

        $model = new Tableaj();
        $bill = new Bill();
        $bill->load(Yii::$app->request->post());
        $model->load(Yii::$app->request->post());
         if (Yii::$app->request->post()){
            $kots = Kot::getKotNotInBillKot($model->name);
            echo 'table '.$model->name;
        
            $newBill = new Bill();
            date_default_timezone_set("Asia/Kolkata"); 
            $newBill->timestamp = date("Y-m-d H:i:s");
            $newBill->payment_mode = strtolower($bill->payment_mode);
            $newBill->discount = $bill->discount;
            $newBill->save();
            
            echo ' timestamp'.$newBill->timestamp;
            echo ' payment_mode'.$newBill->payment_mode;
            echo ' discount'.$newBill->discount;
            echo ' bid'.$newBill->bid;
        
            foreach($kots as $kot){
                $billKot = new Billkot();
                $billKot->bid = $newBill->bid;
                $billKot->kid = $kot->kid;
                $billKot->save();
            }  
              Bill::printBill($newBill->bid); 
              return $this->redirect('index.php');   
        
        }  
    }


    public function actionEdit($bid)
    {

            $model = new Bill();
            $model->load(Yii::$app->request->post());
            $bill = Bill::findOne($bid);
            $bill->discount = $model->discount;
            $bill->payment_mode = $model->payment_mode;
            $bill->save();
           
       
           
        return $this->redirect('index.php');  
    }

    public function actionPrint($bid)
    {

            Bill::printBill($bid);          
        return $this->redirect('index.php');  
    }
    

     /**
     * Updates an existing Bill model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
       
        $bill=Bill::findOne($id);

        $kot = $bill->ks;      
        $orders = $kot[0]->orders;

        $model = Tableaj::findOne($orders[0]->tid);        
        $orders = Orders::getOrdersInBill($id);

        return $this->render('view', [
        'tableaj' => $model,
        'kot'=>$orders,
        'isUpdate' => true,
        'bid'=>$id
        ]);   

    }


    /**
     * Displays a single Bill model.
     * @param integer $id
     * @return mixed
     */
   

    /**
     * Creates a new Bill model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Bill();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->bid]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

   

    /**
     * Deletes an existing Bill model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Bill model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Bill the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Bill::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
