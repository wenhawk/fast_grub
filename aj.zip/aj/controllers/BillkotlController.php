<?php

namespace app\controllers;

use Yii;
use app\models\Billkot;
use app\models\BillkotSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * BillkotlController implements the CRUD actions for Billkot model.
 */
class BillkotlController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Billkot models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new BillkotSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Billkot model.
     * @param integer $bid
     * @param integer $kid
     * @return mixed
     */
    public function actionView($bid, $kid)
    {
        return $this->render('view', [
            'model' => $this->findModel($bid, $kid),
        ]);
    }

    /**
     * Creates a new Billkot model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Billkot();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'bid' => $model->bid, 'kid' => $model->kid]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing Billkot model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $bid
     * @param integer $kid
     * @return mixed
     */
    public function actionUpdate($bid, $kid)
    {
        $model = $this->findModel($bid, $kid);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'bid' => $model->bid, 'kid' => $model->kid]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Billkot model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $bid
     * @param integer $kid
     * @return mixed
     */
    public function actionDelete($bid, $kid)
    {
        $this->findModel($bid, $kid)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Billkot model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $bid
     * @param integer $kid
     * @return Billkot the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($bid, $kid)
    {
        if (($model = Billkot::findOne(['bid' => $bid, 'kid' => $kid])) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
