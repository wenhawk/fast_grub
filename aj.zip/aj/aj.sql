-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 30, 2017 at 11:43 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aj`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE IF NOT EXISTS `bill` (
  `bid` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `payment_mode` enum('cash','card') NOT NULL,
  `discount` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `billkot`
--

CREATE TABLE IF NOT EXISTS `billkot` (
  `bid` int(11) NOT NULL,
  `kid` int(11) NOT NULL,
  `flag` enum('true','false') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `cid` int(11) NOT NULL,
  `name` varchar(250) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cid`, `name`) VALUES
(3, ' Waffles'),
(12, 'Beverage'),
(7, 'Coffee'),
(11, 'Cold Cuts'),
(10, 'Eggs'),
(4, 'Pancakes'),
(5, 'Sides'),
(6, 'Tea'),
(2, 'Wings');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `iid` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `description` text,
  `cost` int(11) NOT NULL,
  `flag` enum('true','false') NOT NULL DEFAULT 'true',
  `cat` varchar(100) DEFAULT '-'
) ENGINE=InnoDB AUTO_INCREMENT=256 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`iid`, `name`, `description`, `cost`, `flag`, `cat`) VALUES
(1, '''O'' Shake', 'xd', 120, 'true', '''O'' Shake'),
(3, 'AJ''s Classic Beef Burger', '', 300, 'true', 'AJ''s Classic Beef Burger'),
(4, 'Spicy Pork Pizza', 'asd', 320, 'true', 'Spicy Pork Pizza'),
(5, 'Veg Pasta', '.', 220, 'true', 'Veg Pasta'),
(6, 'Chicken Pasta', '.', 250, 'true', 'Chicken Pasta'),
(7, 'Chourico Pasta', '.', 250, 'true', 'Chourico Pasta'),
(8, 'Veg Bake', '.', 220, 'true', 'Veg Bake'),
(9, 'Chicken Bake', '.', 250, 'true', 'Chicken Bake'),
(10, 'Veg Lasagne', '.', 250, 'true', 'Veg Lasagne'),
(11, 'Chicken Lasagne', '.', 280, 'true', 'Chicken Lasagne'),
(12, 'Beef Lasagne', '.', 280, 'true', 'Beef Lasagne'),
(13, 'Mac & Cheese', '.', 240, 'true', 'Mac & Cheese'),
(14, 'Chourico Ovos', '.', 180, 'true', 'Chourico Ovos'),
(15, 'Mince Ovos', '.', 180, 'true', 'Mince Ovos'),
(18, 'Bacon & Honey Waffles', '.', 200, 'false', 'Bacon & Honey Waffles'),
(19, 'Crumb Fried Chicken Waffles', '.', 200, 'false', 'Crumb Fried Chicken Waffles'),
(20, 'Chocolate Waffles', '.', 200, 'false', 'Chocolate Waffles'),
(26, 'Spaghetti Bolognaise', '.', 300, 'true', 'Spaghetti Bolognaise'),
(27, 'Beefaroni', '.', 250, 'true', 'Beefaroni'),
(28, 'Margherita', '.', 220, 'false', 'Margherita'),
(29, 'Cottage Cheese', '.', 280, 'true', 'Cottage Cheese'),
(105, 'Minute Steak Burger', '', 370, 'true', 'Minute Steak Burger'),
(106, 'Grilled Chicken Burger', '', 280, 'true', 'Grilled Chicken Burger'),
(107, 'Fried Chicken Burger ', '', 280, 'true', 'Fried Chicken Burger '),
(108, 'Pork Burger', '', 280, 'true', 'Pork Burger'),
(109, 'Pulled Pork Burger', '', 320, 'true', 'Pulled Pork Burger'),
(110, 'Chourico Burger', '', 320, 'true', 'Chourico Burger'),
(111, 'TOWM Muffin', '', 320, 'true', 'TOWM Muffin'),
(112, 'Meat Mash Burger', '', 320, 'true', 'Meat Mash Burger'),
(113, 'Egg Muffin Burger', '', 220, 'true', 'Egg Muffin Burger'),
(114, 'Veggie Burger', '', 170, 'true', 'Veggie Burger'),
(115, 'Cottage Cheese Burger', '', 200, 'true', 'Cottage Cheese Burger'),
(116, 'BBQ Chicken Pizza', '', 300, 'true', 'BBQ Chicken Pizza'),
(117, 'Spicy Chicken Pizza', '', 320, 'true', 'Spicy Chicken Pizza'),
(118, 'Chourico Pizza', '', 280, 'true', 'Chourico Pizza'),
(119, 'Beef Mince Piza', '', 300, 'true', 'Beef Mince Piza'),
(120, 'Ovos Pizza', '', 250, 'true', 'Ovos Pizza'),
(121, 'Veggie Pizza', '', 250, 'true', 'Veggie Pizza'),
(122, 'Cottage Cheese Pizza', '', 280, 'true', 'Cottage Cheese Pizza'),
(123, 'Margherita Pizza', '', 220, 'true', 'Margherita Pizza'),
(124, 'Roast Chicken', '', 350, 'true', 'Roast Chicken'),
(125, 'Chicken Roulade', '', 350, 'true', 'Chicken Roulade'),
(126, 'Steak', '', 400, 'true', 'Steak'),
(127, 'Pork Ribs', '', 370, 'true', 'Pork Ribs'),
(128, 'Comfort Fries', '', 100, 'true', 'Comfort Fries'),
(129, 'Chili Cheese Fries', '', 180, 'true', 'Chili Cheese Fries'),
(130, 'Beef Bacon Fries', '', 220, 'true', 'Beef Bacon Fries'),
(131, 'Chicken Poutine Fries', '', 220, 'true', 'Chicken Poutine Fries'),
(132, 'Classic Club Sandwich', '', 200, 'true', 'Classic Club Sandwich'),
(134, 'Garlic Cheese Bread', '', 70, 'true', 'Garlic Cheese Bread'),
(135, 'Brownie', '', 120, 'true', 'Brownie'),
(136, 'Banofee Pie', '', 150, 'true', 'Banofee Pie'),
(137, 'Bread & Butter Pudding', '', 80, 'true', 'Bread & Butter Pudding'),
(138, 'Chocolate ''O'' Mousse', '', 180, 'true', 'Chocolate ''O'' Mousse'),
(147, 'Hot Chocolate Shake', '', 120, 'true', 'Hot Chocolate Shake'),
(148, 'Cold Chocolate Shake', '', 120, 'true', 'Cold Chocolate Shake'),
(149, 'Fresh Lime Soda', '', 50, 'true', 'Fresh Lime Soda'),
(150, 'Fresh Lime Water', '', 50, 'true', 'Fresh Lime Water'),
(151, 'Mojito (Virgin)', '', 100, 'true', 'Mojito (Virgin)'),
(152, 'Soft Drink', '', 30, 'true', 'Soft Drink'),
(153, 'Bottled H2O', '', 20, 'true', 'Bottled H2O'),
(154, 'test', 'test', 777, 'false', 'test'),
(161, 'English Breakfast', '', 320, 'true', 'English Breakfast'),
(162, 'Lite Breakfast', '', 80, 'true', 'Lite Breakfast'),
(163, 'Cold Coffee', '', 100, 'true', 'Cold Coffee'),
(164, 'Coffee', '', 50, 'true', 'Coffee'),
(165, 'Tea', '', 50, 'true', 'Tea'),
(166, 'Waffles', '', 200, 'true', 'Waffles'),
(167, 'Pancakes', '', 180, 'true', 'Pancakes'),
(168, 'Wings', '', 270, 'true', 'Wings'),
(169, 'Sides', '', 50, 'true', 'Sides');

-- --------------------------------------------------------

--
-- Table structure for table `item_category`
--

CREATE TABLE IF NOT EXISTS `item_category` (
  `iid` int(11) NOT NULL,
  `cid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item_category`
--

INSERT INTO `item_category` (`iid`, `cid`) VALUES
(161, 10),
(161, 11),
(161, 12),
(162, 10),
(164, 7),
(165, 6),
(166, 3),
(167, 4),
(168, 2),
(169, 5);

-- --------------------------------------------------------

--
-- Table structure for table `kot`
--

CREATE TABLE IF NOT EXISTS `kot` (
  `kid` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `tid` int(11) NOT NULL,
  `iid` int(11) NOT NULL,
  `kid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `flag` enum('true','false') NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sub_item`
--

CREATE TABLE IF NOT EXISTS `sub_item` (
  `sid` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `flag` enum('true','false') NOT NULL DEFAULT 'true'
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_item`
--

INSERT INTO `sub_item` (`sid`, `name`, `flag`) VALUES
(1, 'Aj''s Spicy Chicken', 'true'),
(2, 'BBQ Chicken', 'true'),
(3, 'Oriental Chicken', 'true'),
(4, 'Racheado Chicken', 'true'),
(5, 'Simply Baked Chicken', 'true'),
(6, 'Chicken Sausages', 'true'),
(7, 'Chocolate Sauce', 'true'),
(8, 'Bacon & Honey', 'true'),
(9, 'Crumb Fried Chicken', 'true'),
(10, 'Chocolate', 'true'),
(11, 'Baked Beans', 'true'),
(12, 'Grilled Tomato', 'true'),
(13, 'Sauteed Mushrooms', 'true'),
(14, 'Hash Browns', 'true'),
(15, 'Pork Sausages', 'true'),
(16, 'Ham', 'true'),
(17, 'Bacon', 'true'),
(18, 'Chicken Salami', 'true'),
(19, 'Chocolate Sauce', 'true'),
(20, 'BBQ Sauce', 'true'),
(21, 'Spicy Sauce', 'true'),
(22, 'Masala Tea', 'true'),
(23, 'Black Tea', 'true'),
(24, 'Iced Tea', 'true'),
(25, 'Green Tea', 'true'),
(26, 'Regular Coffee', 'true'),
(27, 'Black Coffee', 'true'),
(28, 'Iced Coffee', 'true'),
(29, 'Banana & Honey Pancakes', 'true'),
(30, 'Garlic Bread', 'true'),
(34, 'Poached', 'true'),
(35, 'Over Easy', 'true'),
(36, 'Sunny Side Up', 'true'),
(37, 'Masala Omlet', 'true'),
(38, 'Scrambled', 'true'),
(39, 'Omlette', 'true'),
(40, 'Fried', 'true');

-- --------------------------------------------------------

--
-- Table structure for table `sub_item_category`
--

CREATE TABLE IF NOT EXISTS `sub_item_category` (
  `sid` int(11) NOT NULL,
  `cid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_item_category`
--

INSERT INTO `sub_item_category` (`sid`, `cid`) VALUES
(1, 2),
(2, 2),
(3, 2),
(4, 2),
(5, 2),
(6, 5),
(7, 4),
(8, 3),
(9, 3),
(10, 3),
(11, 5),
(12, 5),
(13, 5),
(14, 5),
(15, 5),
(16, 5),
(16, 11),
(17, 5),
(17, 11),
(18, 5),
(18, 11),
(19, 5),
(20, 5),
(21, 5),
(22, 6),
(22, 12),
(23, 6),
(23, 12),
(24, 6),
(24, 12),
(25, 6),
(25, 12),
(26, 7),
(26, 12),
(27, 7),
(27, 12),
(28, 7),
(28, 12),
(29, 4),
(30, 5),
(34, 10),
(35, 10),
(36, 10),
(37, 10),
(38, 10),
(39, 10),
(40, 10);

-- --------------------------------------------------------

--
-- Table structure for table `tableaj`
--

CREATE TABLE IF NOT EXISTS `tableaj` (
  `tid` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `flag` enum('true','false') NOT NULL DEFAULT 'true'
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tableaj`
--

INSERT INTO `tableaj` (`tid`, `name`, `flag`) VALUES
(8, 'Table 1', 'true'),
(9, 'Table 2', 'true'),
(10, 'Table 3', 'true'),
(11, 'Table 4', 'true'),
(12, 'Table 5', 'true'),
(13, 'Table 6', 'true');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`bid`),
  ADD UNIQUE KEY `timestamp` (`timestamp`);

--
-- Indexes for table `billkot`
--
ALTER TABLE `billkot`
  ADD PRIMARY KEY (`bid`,`kid`),
  ADD KEY `kid` (`kid`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cid`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`iid`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `item_category`
--
ALTER TABLE `item_category`
  ADD PRIMARY KEY (`iid`,`cid`),
  ADD KEY `iid` (`iid`),
  ADD KEY `cid` (`cid`);

--
-- Indexes for table `kot`
--
ALTER TABLE `kot`
  ADD PRIMARY KEY (`kid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`tid`,`iid`,`kid`,`rank`),
  ADD KEY `iid` (`iid`),
  ADD KEY `kid` (`kid`),
  ADD KEY `tid` (`tid`),
  ADD KEY `rank` (`rank`);

--
-- Indexes for table `sub_item`
--
ALTER TABLE `sub_item`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `sub_item_category`
--
ALTER TABLE `sub_item_category`
  ADD PRIMARY KEY (`sid`,`cid`),
  ADD KEY `sid` (`sid`),
  ADD KEY `cid` (`cid`);

--
-- Indexes for table `tableaj`
--
ALTER TABLE `tableaj`
  ADD PRIMARY KEY (`tid`),
  ADD UNIQUE KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=62;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `iid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=256;
--
-- AUTO_INCREMENT for table `kot`
--
ALTER TABLE `kot`
  MODIFY `kid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=139;
--
-- AUTO_INCREMENT for table `sub_item`
--
ALTER TABLE `sub_item`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `tableaj`
--
ALTER TABLE `tableaj`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `billkot`
--
ALTER TABLE `billkot`
  ADD CONSTRAINT `billkot_ibfk_1` FOREIGN KEY (`bid`) REFERENCES `bill` (`bid`),
  ADD CONSTRAINT `billkot_ibfk_2` FOREIGN KEY (`kid`) REFERENCES `kot` (`kid`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`tid`) REFERENCES `tableaj` (`tid`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`iid`) REFERENCES `item` (`iid`),
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`kid`) REFERENCES `kot` (`kid`);

--
-- Constraints for table `sub_item_category`
--
ALTER TABLE `sub_item_category`
  ADD CONSTRAINT `sub_item_category_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `category` (`cid`),
  ADD CONSTRAINT `sub_item_category_ibfk_2` FOREIGN KEY (`sid`) REFERENCES `sub_item` (`sid`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
