<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>

<style>

.col-md-4{
   border: 2px solid black;
   padding: 40px;   
}


#delete{
  position: fixed !important;
  right: 1%;
  top: 90%;
  width:50px;
  height:50px;
  font-size:25px;
  text-align:center;
}

#insert{
  position: fixed !important;
  right: 1%;
  top: 80%;
  width:50px;
  height:50px;
  font-size:25px;
  text-align:center;
}

#view{
  position: fixed !important;
  right: 1%;
  top: 70%;
  width:50px;
  height:50px;
  font-size:25px;
  text-align:center;
}





</style>
<center>
<div class = 'container'>
<div class = 'row'>
    <?php foreach($table as $t) {?>
    <div class = 'col-md-4'>         
         
        <h3> <a href='index.php?r=tableaj/delete-table&amp;tid=<?=$t->tid ?>' class='btn btn-danger'> X </a> </h2>

        <h1><?= $t->name ?></h1>

        <a href= 'index.php?r=kot/generate&amp;id=<?=$t->tid ?>'> 
            <h3>Generate Kot</h3>
        </a>    
        <a href= 'index.php?r=bill/view&amp;id=<?=$t->tid ?>'> 
            <h3>Generate Bill</h3>
        </a>
        <a href= 'index.php?r=kot/view-table-kot&amp;tid=<?=$t->tid ?>'> 
            <h3>Table Status</h3>
        </a>
    </div>
    <?php }?>
</div>
</div>
</center>  
<div class='col-md-3'>
        <h2> <a id='delete' href='index.php?r=tableaj/show-deleted-table' class='btn btn-success'> - </a> </h2>
        </div>
        <div class='col-md-3'>
        <h2> <a id='insert' href='index.php?r=tableaj/create' class='btn btn-success'> + </a> </h2>
        </div>
        <div class='col-md-3'>
        <h2> <a id='view' href='index.php?r=orders/view-all-orders' class='btn btn-success'> V </a> </h2>
        </div>