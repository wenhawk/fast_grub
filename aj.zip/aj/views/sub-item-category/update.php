<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\SubItemCategory */

$this->title = 'Update Sub Item Category: ' . $model->sid;
$this->params['breadcrumbs'][] = ['label' => 'Sub Item Categories', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->sid, 'url' => ['view', 'sid' => $model->sid, 'cid' => $model->cid]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="sub-item-category-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
