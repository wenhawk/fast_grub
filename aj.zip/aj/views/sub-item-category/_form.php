<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\SubItem;
use app\models\SubItemCategory;
use app\models\Category;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model app\models\ItemCategory */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="item-category-form">

    <?php  
    //$item = SubItemCategory::find()->all();   
    /* $query = SubItem::find()->where(['not in','sid',$item])->all(); */
    $query = SubItem::find()->all();
    ?>
    <?php $form = ActiveForm::begin(); ?>

    <div class='row'> 
    <?= $form->field($model,'cid')->dropDownList(
        ArrayHelper::map(Category::find()->all(), 'cid','name'),
        ['prompt'=>'Select CATEGORY',
    ]);?>
    </div>

    <div class='row'> 

    <?php foreach($query as $q) {?>
    <div class='col-md-4'>
    <input id="subitemcategory-sid" class="form-control" name="SubItemCategory[sid][]" value="<?=$q->sid?>" type="hidden">
    <?= $form->field($model, 'flag[]')->checkbox(['label'=>$q->name]); ?>
    </div>
    <?php }?>

    </div>


    

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
