<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\OrdersSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */


?>
<div class='container'>



    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

           
            [
                'attribute'=>'iid',
                'value'=>'i.name'
            ],

            'quantity',
            [
                'attribute'=>'tid',
                'value'=>'t.name'
            ],
            'kid',

            ['class' => 'yii\grid\ActionColumn',
            'visibleButtons' => [
                'view' => Yii::$app->user->can('update'), // or whatever condition
                'delete' => Yii::$app->user->can('update')
            ]],
            
        ],
    ]); ?>
</div>
