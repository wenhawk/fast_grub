<?php


?>

<style>
#delete{
  position: fixed !important;
  right: 1%;
  top: 90%;
  width:50px;
  height:50px;
  font-size:25px;
  text-align:center;
}

#insert{
  position: fixed !important;
  right: 1%;
  top: 80%;
  width:50px;
  height:50px;
  font-size:25px;
  text-align:center;
}


#home{
  position: fixed !important;
  right: 1%;
  top: 70%;
  width:50px;
  height:50px;
  font-size:25px;
  text-align:center;
}

</style>
<div class='container'>
<div class="row">
    <div class='col-md-6'>
        <table class='table'>
        
        <th><h3>ITEM</h3></th>
        <th><h3>TABLE</h3></th>
        <th><h3>Qt</h3></th>
        <th><h3>E</h3></th>
        
        <?php foreach($model as $order) {?>
        <?php if($order->status==0) {?>
            <tr class='danger'>
            <td><?= $order->i->name?></td>
            <td><?= $order->t->name?></td>
            <td><?= $order->quantity?></td>        
            
            <td>
            <a href="index.php?r=orders/update&amp;kid=<?=$order->kid?>
            &amp;tid=<?=$order->tid?>
            &amp;iid=<?=$order->iid?>
            &amp;rank=<?=$order->rank?>
            &amp;status=<?=1?>"> MARK AS SERVED </a>
            
            </td>
        </tr>     
        <?php } else {?>
            <tr class='success'>
        <?php } ?>
        
             
    
        <?php }?>
        </table>
    </div>

    <div class='col-md-6'>
    <table class='table'>
    
    <th><h3>ITEM</h3></th>
    <th><h3>TABLE</h3></th>
    <th><h3>Qt</h3></th>
    <th><h3>E</h3></th>
    
    <?php foreach($model as $order) {?>
    <?php if($order->status==0) {?>
        <tr class='danger'>
           
    <?php } else {?>
        <tr class='success'>
        <td><?= $order->i->name?></td>
        <td><?= $order->t->name?></td>
        <td><?= $order->quantity?></td>        
        
        <td>
        <a href="index.php?r=orders/update&amp;kid=<?=$order->kid?>
        &amp;tid=<?=$order->tid?>
        &amp;iid=<?=$order->iid?>
        &amp;rank=<?=$order->rank?>
        &amp;status=<?=0?>"> MARK NOT SERVED </a>
        
        </td>
    </tr>  
    <?php } ?>
    
         

    <?php }?>
    </table>
    </div>
   
</div>
</div>
<div class='col-md-3'>
        <h2> <a id='delete' href='index.php?r=tableaj/show-deleted-table' class='btn btn-success'> - </a> </h2>
        </div>
        <div class='col-md-3'>
        <h2> <a id='insert' href='index.php?r=tableaj/create' class='btn btn-success'> + </a> </h2>
        </div>
        <div class='col-md-3'>
        <h2> <a id='home' href='index.php?r=site/index' class='btn btn-success'> H </a> </h2>
        </div>