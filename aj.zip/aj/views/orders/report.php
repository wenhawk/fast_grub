<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\widgets\ActiveForm;
use app\models\Cupon;

/* @var $this yii\web\View */
/* @var $model app\models\Cupon */


?>

<?php 



?>

<div class="container">

<center><h1>SUMMARY<h1></center>
<center>
<div class='row'>

    <div class='col-md-3'>
    <h3>KOT</h3>
    <h4><?= sizeof($kot)?></h4>
    </div>

    <div class='col-md-3'>
    <h3>INCOME</h3>
     <h4> Rs <?= ' '.$cost?></h4>
    </div>

    <div class='col-md-3'>
    <h3>ORDERS</h3> 
    <h4><?=  sizeof($allOrders) ?></h4>
    </div>

    <div class='col-md-3'>
    <h3>ITEMS</h3>
    <h4><?=  sizeof($orderItem) ?></h4>
    </div>

    <div class='col-md-3'>
    <h3>CASH</h3>
    <h4><?=  $cash ?></h4>
    </div>

    <div class='col-md-3'>
    <h3>CARD</h3>
    <h4><?=  $card ?></h4>
    </div>
    

</div>
</center>
<br><br><br>    


<div class='row'>

<table id="myTable" class="table table-condensed">

    <th> <h3>  </h3></th>
    <th> <h3> ITEM </h3></th>
    <th> <h3> QUANTITY </h3> </th>
    <th> <h3> COST </h3> </th>


    <?php for($i = 0 ; $i < sizeof($orderItem) ; $i++){ ?>
      <tr>
      <td><h4><?= $i + 1 ?></h4></td>
      <td><h4><?= $orderItem[$i]->i->name ?></h4></td>
      <td><h4><?= $quantity[$i] ?></h4></td>
      <td><h4><?= $orderItem[$i]->i->cost * $quantity[$i] ?></h4></td>
      </tr>
    <?php }?>

</table> 
</div>



<center>


</center>
</div>
