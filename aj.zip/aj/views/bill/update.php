<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use app\models\Orders;
use app\models\Item;
use app\models\Tableaj;
use app\models\KotItem;
use app\models\Kot;
use app\models\FormOrder;

/* @var $this yii\web\View */
/* @var $searchModel app\models\ItemSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
$model = new FormOrder();
?>
<div class='container'>
<?php 
   $form = ActiveForm::begin(['action' => 'index.php?r=bill/edit']);
?>


<div class='row'>
<center><h1> BILL </h1> 
</center>

    <div class='col-md-0'>

    </div>

    <div class='col-md-12'>  

    <?php $count=1 ;
    $totalCost = 0;
    ?>
    <table id="myTable" class="table table-condensed">
    <th> <h4> Sr. No. </h4></th>
    <th> <h4> ITEM </h4></th>
    <th> <h4> QUANTITY </h4> </th>
    <th> <h4> PRICE </h4> </th>
    <th> <h4> DELETE </h4> </th>
    <?php foreach($kot as $k){ ?>
        <input id="formorder-uniquekid" class="form-control" name="FormOrder[uniqueKid][]" value="<?= $k->kid?>" type="hidden"> 
        <?php $orders   = $k->orders;
         foreach($orders as $order){ ?>
         <?php 
         if($order->flag=='true'){
            $totalCost = $totalCost + ($order->quantity * $order->i->cost);
         ?>
         <input id="formorder-kid" class="form-control" name="FormOrder[kid][]" value="<?= $k->kid?>" type="hidden">
            <tr>
            <td><h4><?= $count ?></h4></td>
             <td><h4><?= $order->i->name?><input id="formorder-iid" class="form-control" name="FormOrder[iid][]" value="<?= $order->iid?>" type="hidden"></h4></td>
             <td><h4><input id="formorder-quantity" class="form-control" name="FormOrder[quantity][]" value="<?= $order->quantity?>" type="number"></h4></td>
             <td><h4><?= $order->quantity * $order->i->cost ?></h4></td>
             <td><?= $form->field($model, 'flag[]')->checkbox(['label'=>'']); ?></td>
            </tr>       
         <?php }?>
        <?php $count++; } ?>       
     
    <?php } ?> 
    </table>  
    
   
    </div>
        
    
    <div class= 'row'>
    <div class='col-md-4'>
    <div class="form-group field-formorder-paymentmode required">
    <label class="control-label" for="formorder-paymentmode">Payment Mode</label>
    <select id="formorder-paymentmode" class="form-control" name="FormOrder[paymentMode]" aria-required="true">
    <?php if($bill->payment_mode == 'cash' ) {?>
    <option value="cash">CASH</option>    
    <option value="card">CARD</option>
    <?php } else { ?>
    <option value="cash">CARD</option>    
    <option value="card">CASH</option>
    <?php } ?>
    </select>
    <div class="help-block"></div>
    </div>
    </div>
    
    <div class='col-md-4'>
    <?= $form->field($model, 'discount')->textInput(['value'=>$bill->discount,'type'=>'number']); ?>
    </div>

    <div class='col-md-1'>
    
    </div>

    <div class='col-md-3'>
    <input id="tableaj-name" class="form-control" name="Tableaj[name]" value="8" aria-required="true" type="hidden">
    <h2>Total: <?= $totalCost   ?><h2>
    </div>
   
    </div>
    
    <center>
    
    <div class="form-group">  
    <center><?= Html::submitButton('GENERATE BILL', ['class' => 'btn btn-success']) ?></center>
    </div>
    </center>
    <?php ActiveForm::end(); ?>

            

</div>

