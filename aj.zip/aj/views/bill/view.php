<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;
use app\models\Tableaj;
use app\models\Bill;

/* @var $this yii\web\View */
/* @var $searchModel app\models\ItemSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
$table = new Tableaj();
$bill = new Bill();
?>

<div class='container'>
<?php
if($isUpdate){
    $form = ActiveForm::begin(['action' => 'index.php?r=bill/edit&bid='.$bid]);
}else{

    $form = ActiveForm::begin(['action' => 'index.php?r=bill/insert']);
}
?>


<div class='row'>
<center><h1> BILL </h1>
</center>

    <div class='col-md-0'>

    </div>

    <div class='col-md-12'>

    <?php $count=1 ;
    $totalCost = 0;
    ?>
    <table id="myTable" class="table table-condensed">
    <th> <h4> Sr. No. </h4></th>
    <th> <h4> ITEM </h4></th>
    <th> <h4> QUANTITY </h4> </th>
    <th> <h4> PRICE </h4> </th>
    <?php foreach($kot as $k){ ?>
        <input id="formorder-uniquekid" class="form-control" name="FormOrder[uniqueKid][]" value="<?= $k->kid?>" type="hidden">
        
         <input id="formorder-kid" class="form-control" name="FormOrder[kid][]" value="<?= $k->kid?>" type="hidden">
            <tr>
            <td><h4><?= $count ?></h4></td>
             <td><h4><?= $k->i->cat?><input id="formorder-iid" class="form-control" name="FormOrder[iid][]" value="<?= $k->iid?>" type="hidden"></h4></td>
             <td><h4><?= $k->quantity?></h4></td>
             <td><h4><?= $k->quantity * $k->i->cost ?></h4></td>
            </tr>
        
        <?php 
        $totalCost = $totalCost + $k->quantity * $k->i->cost;
        $count++; } ?>


    </table>


    </div>


    <div class= 'row'>
    <div class='col-md-4'>
    <?= $form->field($bill, 'payment_mode')->dropDownList(['cash' => 'CASH', 'card' => 'CARD']); ?>
    </div>

    <div class='col-md-4'>
    <?= $form->field($bill, 'discount')->textInput(['value'=>0,'type'=>'number']); ?>
    </div>

    <div class='col-md-1'>

    </div>

    <div class='col-md-3'>
    <input id="tableaj-name" class="form-control" name="Tableaj[name]" value="<?= $tableaj->tid?>" aria-required="true" type="hidden">
    <h2>Total: <?= $totalCost   ?><h2>
    </div>

    </div>

    <center>
    <br>
    <div class='row'>
        <div class='col-md-3'>
        
        </div>  
        <div class='col-md-3'>
        <center><button class='btn btn-success'>UPDATE</button></center>
        </div>
        <div class='col-md-3'>
        <?php if($isUpdate) {?>
        <center><a href='index.php?r=bill/print&amp;bid=<?= $bid?>'><h2>PRINT</a></h2></center>
        </div>    
        <?php }?>
        <div class='col-md-3'>
        
        </div>  
    </div>
    </center>
    <?php ActiveForm::end(); ?>



</div>
