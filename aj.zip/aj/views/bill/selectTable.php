<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use app\models\Orders;
use app\models\Item;
use app\models\Tableaj;
use app\models\KotItem;

/* @var $this yii\web\View */
/* @var $searchModel app\models\ItemSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

?>


<?php $form = ActiveForm::begin(); ?>   
    <div class="row">
    
    <?php foreach($orders as $o) {?>
    <div class='col-md-3'>
    <a class="img-card" href="index.php?r=bill/view&amp;id=<?=$o->tid ?>">
    <h2>
    <p><?= $o->t->name ?><p>       
    <h2 > 
    </a>       
    </div>
    <?php }?>
    

</div>
