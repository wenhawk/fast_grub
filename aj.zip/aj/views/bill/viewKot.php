<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use app\models\Orders;
use app\models\FormOrder;
use app\models\Item;
use app\models\Tableaj;

/* @var $this yii\web\View */
/* @var $searchModel app\models\ItemSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'KOT Generator';
$this->params['breadcrumbs'][] = $this->title;
?>

<?php 
    $model = new FormOrder();
    $form = ActiveForm::begin([
    'action'=>'index.php?r=kot/update-and-print'
]); ?>   

<div class="item-index ">
<div class='row'>
    <div class='col-md-3'>

    </div>

    <div class='col-md-6'>
    <h1><?= $orders[0]->t->name?></h1>  
    <table id="myTable" class="table table-condensed">
    <th> <h4> ITEM </h4></th>
    <th> <h4> QUANTITY </h4> </th>
    <th> <h4> SERVED </h4> </th>
    <th> <h4> DELETE </h4> </th>
    <input id="formorder-uniquekid" class="form-control" name="FormOrder[uniqueKid]" value="<?= $orders[0]->kid?>" aria-required="true" type="hidden">
    <?php foreach($orders as $order){ ?>  
        <?php if($order->flag == 'true'){?>      
        <tr>
        <td>
        <h4>
        <?= $order->i->name ?>
        <input id="formorder-iid" class="form-control" name="FormOrder[iid][]" value="<?= $order->iid?>" type="hidden">
        </h4>
        </td>
        <td>
        <h4>
        <input id="formorder-quantity" class="form-control" name="FormOrder[quantity][]" value="<?= $order->quantity?>" type="text">
        </h4>
        </td>
        </td>
        <td>        
        <center> 
        <input name="FormOrder[status][]" value="0" type="hidden"><label>
        <input id="formorder-status" name="FormOrder[status][]" value="1" aria-invalid="false" type="checkbox" <?php if($order->status) echo 'checked'?> </label>
        </center>       
        </td>
        <td>        
        <center><?= $form->field($model, 'flag[]')->checkbox(['label'=>'']); ?></center>       
        </td>
        </tr>  
        <?php }?> 
   
    <?}?> 
    
    </table> 
    </div>

    <div class='col-md-3'>

    </div>



</div>
    <div class='row'><center><button class='btn btn-success'>UPDATE</button></center>    
    </div>
</div>

<?php ActiveForm::end(); ?> 