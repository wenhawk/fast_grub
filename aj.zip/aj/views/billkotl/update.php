<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Billkot */

$this->title = 'Update Billkot: ' . $model->bid;
$this->params['breadcrumbs'][] = ['label' => 'Billkots', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->bid, 'url' => ['view', 'bid' => $model->bid, 'kid' => $model->kid]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="billkot-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
