<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>

<style>

.col-md-4{
   border: 2px solid black;
   padding: 10px;   
}

.row{
   padding: 20px;   
}



</style>
<center>
<div class = 'container'>

<div class = 'row'>
    <?php foreach($model as $t) {?>
    <div class = 'col-md-4'>         
         
        <h3> <a href='index.php?r=tableaj/restore-table&amp;tid=<?=$t->tid ?>' class='btn btn-success'> RESTORE </a> </h2>

        <h1><?= $t->name ?></h1>

        </div>
    <?php }?>
</div>
</div>
</center>