<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Tableaj */

$this->title = 'Update Table: ' . $model->name;
$this->params['breadcrumbs'][] = ['label' => 'Tableajs', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->name, 'url' => ['view', 'id' => $model->tid]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="tableaj-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
