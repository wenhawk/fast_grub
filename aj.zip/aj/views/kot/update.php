<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Kot */

$this->title = 'Update Kot: ' . $model->kid;
$this->params['breadcrumbs'][] = ['label' => 'Kots', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->kid, 'url' => ['view', 'id' => $model->kid]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="kot-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
