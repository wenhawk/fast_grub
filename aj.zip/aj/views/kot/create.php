<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Kot */

$this->title = 'Create Kot';
$this->params['breadcrumbs'][] = ['label' => 'Kots', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="kot-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
