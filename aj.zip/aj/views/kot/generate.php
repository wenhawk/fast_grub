<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use app\models\Orders;
use app\models\Item;
use app\models\Tableaj;
use app\models\KotItem;

/* @var $this yii\web\View */
/* @var $searchModel app\models\ItemSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

?>


<?php 
        $item = new Item();
        $tableaj = new Tableaj();
        $model = new KotItem();

?>

<style>

.hide{
    visibility: hidden;
}


</style>

<div class='container'> 

    <?php $form = ActiveForm::begin(); ?>   
   
    <div class="item-form">

        <div class="row">
        
            <div class="col-md-3">
            </div>           
          
            <input id="tableaj-tid" class="form-control" name="Tableaj[tid]" value='<?= $tableID ?>' type="hidden">

            <div class="col-md-6">
            <? echo $form->field($item, 'name')->widget(Select2::classname(), [
            'data' =>  ArrayHelper::map(Item::find()->where(['flag'=>'true'])->all(), 'iid','name'),
            'language' => 'en',
            'options' => 
            ['placeholder' => 'select',
            'onchange'=>'getData()'],
            'pluginOptions' => [
                'allowClear' => true
            ],
            ]);
            ?>
            </div>

            <div class="col-md-3">
            </dev>

    </div>    

    <div class='row' id = 'test'>
    </div>
         
        
        <center><input type="button" class="btn btn-success" value="ADD ITEM" onclick="addField();"> <br><br></center>
        <table id="myTable" class="table table-condensed">
            <th>ITEM</th>
            <th>QUANTITY</th>
        </table> 

    <div class="form-group">  
        <center><?= Html::submitButton('GENERATE KOT', ['class' => 'btn btn-success']) ?></center>
    </div>
   
    <?php ActiveForm::end() ?>        
</div>
</div>

<script>

    function isTouchDevice() {  
        return 'ontouchstart' in window || 'onmsgesturechange' in window; 
    }

    rowCount = 1;
    function addField (argument) {
        
            var divisionTest = document.getElementById("test");

            var myTable = document.getElementById("myTable");
            var currentIndex = myTable.rows.length;
            var currentRow = myTable.insertRow(-1);
            
            var button = document.createElement("button");
            button.innerHTML = "X";
            button.className = "btn btn-danger"; 
            button.addEventListener("click", function() {
                p= button.parentNode.parentNode;
                p.parentNode.removeChild(p);
            });

            var item = document.getElementById("item-name");
            var itemValue = item.options[item.selectedIndex].text;

            var table = document.getElementById("tableaj-tid");
            var tableValue = table.value; 

            var quantity = 1;

            var activeItem = document.createElement("input");
            activeItem.className = "form-control";
            activeItem.type = "hidden";
            activeItem.name = "KotItem[item][]";
            activeItem.id = "kotitem-item";
            activeItem.value = item.value;

            var activeQuantity = document.createElement("input");
            activeQuantity.className = "form-control";
            activeQuantity.type = "number";
            activeQuantity.name = "KotItem[quantity][]";
            activeQuantity.id = "kotitem-quantity";
            activeQuantity.value = quantity;

            var activeTable = document.createElement("input");
            activeTable.className = "form-control";
            activeTable.type = "hidden";
            activeTable.name = "KotItem[table][]";
            activeTable.id = "kotitem-table";
            activeTable.value = table.value;

            var activeRank = document.createElement("input");
            activeRank.className = "form-control";
            activeRank.type = "hidden";
            activeRank.name = "KotItem[rank][]";
            activeRank.id = "kotitem-rank";
            activeRank.value = rowCount;

             c = divisionTest.children;
            subItemString = '';
            for(j = 0; j < c.length; j++ ){
                subItemString = subItemString +' '+ c[j].children[0].options[c[j].children[0].selectedIndex].text;
                subItemValue = c[j].children[0].options[c[j].children[0].selectedIndex].value;

                var activeSubItem = document.createElement("input");
                activeSubItem.className = "form-control";
                activeSubItem.type = "hidden";
                activeSubItem.name = "KotItem[subitem][]";
                activeSubItem.id = "kotitem-subitem";                
                activeSubItem.value = subItemValue;   

                currentCell = currentRow.insertCell(-1);
                currentCell.className = 'hide';
                currentCell.appendChild(activeSubItem);   
    
            } 

            
            var activeCount = document.createElement("input");
                activeCount.className = "form-control";
                activeCount.type = "hidden";
                activeCount.name = "KotItem[count][]";
                activeCount.id = "kotitem-count";
                activeCount.value = c.length;

            currentCell = currentRow.insertCell(-1);
            currentCell.className = 'hide';
            currentCell.appendChild(activeCount);  
                      
        
            var t1 = document.createTextNode(itemValue+' '+subItemString);  
            var t2 = document.createTextNode(tableValue);
            var t3 = document.createTextNode(quantity);  

            var p1 = document.createElement("P");
            p1.setAttribute("name", "item" + currentIndex);
            p1.appendChild(t1); 

            var p3 = document.createElement("P");
            p3.setAttribute("name", "quantity" + currentIndex);
            p3.appendChild(t3); 

            var currentCell = currentRow.insertCell(-1);
            currentCell.appendChild(p1);

            currentCell = currentRow.insertCell(-1);
            currentCell.appendChild(activeQuantity);
 
            currentCell = currentRow.insertCell(-1);
            currentCell.appendChild(activeItem);

            currentCell = currentRow.insertCell(-1);
            currentCell.appendChild(activeTable);    

            currentCell = currentRow.insertCell(-1);
            currentCell.appendChild(activeRank);          

            currentCell = currentRow.insertCell(-1);
            currentCell.appendChild(button);            
            rowCount++;          
        }   

        function SomeDeleteRowFunction(o) {
        var p=o.parentNode.parentNode;   
        }

        var divisionTest = document.getElementById("test");

        function getData(){            
            divisionTest.innerHTML = '';
            var item = document.getElementById("item-name");
            var itemValue = item.value;
            var ourRequest = new XMLHttpRequest();
            if(isTouchDevice()){              
            ourRequest.open( 'GET' , 'http://192.168.1.9/aj/web/index.php?r=kot%2Fajax&id='+itemValue);  
            }
            else{
            ourRequest.open( 'GET' , 'http://localhost/aj/web/index.php?r=kot%2Fajax&id='+itemValue);
            }
            ourRequest.onload = function (){
            console.log(ourRequest.responseText)
            console.log(itemValue)
            var ourData = JSON.parse(ourRequest.responseText);              
            renderHTML(ourData);          
            };
        ourRequest.send();   
        }

        function renderHTML(data){
            divisionTest.innerHTML = '';
            string = '';
            for(i = 0;i < data.length ; i++){
                string = string + '<div class=\"col-md-4\">';
                string = string + '<select  class=\"form-control\">'
                for(j = 0; j < data[i].length ;j++){                    
                    string = string + '<option value=\"'+data[i][j].sid+'\">'+ data[i][j].name + '</option>';
                    console.log(data[i][j].name);
                }
                string = string + '</select>'
                string = string + '</div>';
                
            }
            divisionTest.insertAdjacentHTML("beforeend",string);
        } 

    </script>