<?php

use yii\helpers\Html;
use yii\grid\GridView;
use app\models\KotSearch;

/* @var $this yii\web\View */
/* @var $searchModel app\models\KotSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$model = new KotSearch
?>
<div class="container">

    <h2><?= Html::encode($this->title) ?></h2>    
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'kid',
            [
                'attribute' => 'timestamp',
                'value' => 'timestamp',
                'filter' => \yii\jui\DatePicker::widget(['model' => $model,
                'attribute' => 'timestamp','language' => 'en', 'dateFormat' => 'yyyy-MM-dd']),
             
            ],

            ['class' => 'yii\grid\ActionColumn',
            'visibleButtons' => [
                'view' => Yii::$app->user->can('update'), // or whatever condition
                'delete' => Yii::$app->user->can('update')
            ]],
        ],
    ]); ?>
</div>
