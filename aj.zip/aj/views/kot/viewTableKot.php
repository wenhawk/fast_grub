<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use app\models\Orders;
use app\models\FormOrder;
use app\models\Item;
use app\models\Tableaj;

/* @var $this yii\web\View */
/* @var $searchModel app\models\ItemSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'KOT Generator';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class = 'col-md-3'>
</div>

<div class = 'col-md-6'>

<h1> KOTS </h1>
<table class = 'table'>
<?php foreach($kots as $kot ) {?> 
    <tr>
    <td><h2><?= $kot->kid?></h2></td>
    <td><a href='index.php?r=kot/update&amp;id=<?=$kot->kid ?>'> EDIT </a></td>
    </tr>    
    
</div>

<?php }?> 
</table>
</div>
<div class = 'col-md-3'>
</div>
